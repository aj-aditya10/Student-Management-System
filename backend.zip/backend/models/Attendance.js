// backend/models/Attendance.js
const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const User = require('./User');
const Course = require('./Course');

const Attendance = sequelize.define('Attendance', {
  id: { type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true },
  user_id: { type: DataTypes.INTEGER, allowNull: false },
  course_id: { type: DataTypes.INTEGER, allowNull: false },
  date: { type: DataTypes.DATE, allowNull: false },
  status: { type: DataTypes.ENUM('present', 'absent'), allowNull: false },
});

Attendance.belongsTo(User, { foreignKey: 'user_id' });
Attendance.belongsTo(Course, { foreignKey: 'course_id' });

module.exports = Attendance;
