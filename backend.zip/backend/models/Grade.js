// backend/models/Grade.js
const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const User = require('./User');
const Course = require('./Course');

const Grade = sequelize.define('Grade', {
  id: { type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true },
  user_id: { type: DataTypes.INTEGER, allowNull: false },
  course_id: { type: DataTypes.INTEGER, allowNull: false },
  grade: { type: DataTypes.STRING, allowNull: true },
});

Grade.belongsTo(User, { foreignKey: 'user_id' });
Grade.belongsTo(Course, { foreignKey: 'course_id' });

module.exports = Grade;
