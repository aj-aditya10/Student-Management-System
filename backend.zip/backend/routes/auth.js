const express = require('express');
const router = express.Router();

router.post('/login', (req, res) => {
  const { username, password, role } = req.body;
  // Dummy authentication
  if (username && password && role) {
    res.status(200).json({ message: 'Login successful', role });
  } else {
    res.status(400).json({ message: 'Invalid credentials' });
  }
});

module.exports = router;