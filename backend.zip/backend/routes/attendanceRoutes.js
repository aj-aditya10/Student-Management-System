// backend/routes/attendanceRoutes.js
const express = require('express');
const { markAttendance, getAttendance } = require('../controllers/attendanceController');
const router = express.Router();

router.post('/', markAttendance);
router.get('/:course_id/:date', getAttendance);

module.exports = router;
