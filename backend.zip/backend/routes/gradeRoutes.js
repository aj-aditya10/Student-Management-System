// backend/routes/gradeRoutes.js
const express = require('express');
const { addGrade, getGrades } = require('../controllers/gradeController');
const router = express.Router();

router.post('/', addGrade);
router.get('/:course_id', getGrades);

module.exports = router;
