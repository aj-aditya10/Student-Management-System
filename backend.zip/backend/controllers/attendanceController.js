// backend/controllers/attendanceController.js
const Attendance = require('../models/Attendance');

// Mark attendance
exports.markAttendance = async (req, res) => {
  const { user_id, course_id, date, status } = req.body;

  try {
    const attendance = await Attendance.create({ user_id, course_id, date, status });
    res.status(201).json(attendance);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

// Get attendance by course and date
exports.getAttendance = async (req, res) => {
  const { course_id, date } = req.params;

  try {
    const attendance = await Attendance.findAll({
      where: { course_id, date },
    });
    res.status(200).json(attendance);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};
