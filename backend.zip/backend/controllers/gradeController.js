// backend/controllers/gradeController.js
const Grade = require('../models/Grade');

// Add grade
exports.addGrade = async (req, res) => {
  const { user_id, course_id, grade } = req.body;

  try {
    const newGrade = await Grade.create({ user_id, course_id, grade });
    res.status(201).json(newGrade);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

// Get grades for a course
exports.getGrades = async (req, res) => {
  const { course_id } = req.params;

  try {
    const grades = await Grade.findAll({ where: { course_id } });
    res.status(200).json(grades);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};
