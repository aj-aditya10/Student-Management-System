// backend/controllers/courseController.js
const Course = require('../models/Course');

// Get all courses
exports.getAllCourses = async (req, res) => {
  try {
    const courses = await Course.findAll();
    res.status(200).json(courses);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

// Create a new course
exports.createCourse = async (req, res) => {
  const { course_name, course_code, description } = req.body;

  try {
    const course = await Course.create({ course_name, course_code, description });
    res.status(201).json(course);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};
